import React from "react";

const AssignLabour = () => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg sm:text-xl font-semibold text-gray-700">Assign Labour</h3>
      <p className="text-sm sm:text-base text-gray-600">
        Functionality to assign labour will be implemented here.
      </p>
      {/* Add form or logic for assigning labour as needed */}
    </div>
  );
};

export default AssignLabour;