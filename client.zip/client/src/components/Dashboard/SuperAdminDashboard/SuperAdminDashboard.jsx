import React from 'react'

const SuperAdminDashboard = () => {
  return (
    <div>
      SuperAdmin Dashboard
    </div>
  )
}

export default SuperAdminDashboard
