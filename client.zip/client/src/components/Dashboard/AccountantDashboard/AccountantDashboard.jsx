import React from 'react'

const AccountantDashboard = () => {
  return (
    <div>
      Accountant Dashboard
    </div>
  )
}

export default AccountantDashboard
